<?php require 'product.php'; ?>
