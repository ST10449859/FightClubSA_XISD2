<?php
// Development API for FightClubSA. Configure CORS and HTTPS before public deployment.
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // Local development only; restrict this in production.
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
require_once __DIR__ . '/../config/database.php';

function respond(int $status, array $body): never {
    http_response_code($status);
    echo json_encode($body, JSON_UNESCAPED_SLASHES);
    exit;
}
function body(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '{}', true);
    return is_array($data) ? $data : [];
}
$action = $_GET['action'] ?? '';

try {
    if ($action === 'health') {
        respond(200, ['ok' => true, 'service' => 'FightClubSA API']);
    }
    if ($action === 'classes' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $q = $pdo->query('SELECT c.class_id AS id, c.class_name AS name, COALESCE(t.trainer_name, "FightClubSA Trainer") AS trainer, TIME_FORMAT(c.start_time, "%H:%i") AS time, c.level, c.capacity, DATE_FORMAT(c.schedule_date, "%Y-%m-%d") AS date FROM Classes c LEFT JOIN Trainers t ON t.trainer_id=c.trainer_id ORDER BY c.schedule_date, c.start_time');
        respond(200, ['ok' => true, 'classes' => $q->fetchAll()]);
    }
    if ($action === 'register' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $d = body();
        $name = trim((string)($d['full_name'] ?? ''));
        $email = filter_var(trim((string)($d['email'] ?? '')), FILTER_VALIDATE_EMAIL);
        $password = (string)($d['password'] ?? '');
        if ($name === '' || !$email || strlen($password) < 8) respond(422, ['ok'=>false, 'message'=>'Provide a name, valid email and password of at least 8 characters.']);
        $s = $pdo->prepare('INSERT INTO Members (full_name,email,membership_type,password_hash) VALUES (?,?,?,?)');
        try { $s->execute([$name,$email,'Starter',password_hash($password, PASSWORD_DEFAULT)]); }
        catch (PDOException $e) { respond(409, ['ok'=>false,'message'=>'That email may already be registered.']); }
        respond(201, ['ok'=>true,'message'=>'Account created. Please sign in.']);
    }
    if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $d = body();
        $email = filter_var(trim((string)($d['email'] ?? '')), FILTER_VALIDATE_EMAIL);
        $password = (string)($d['password'] ?? '');
        if (!$email || $password === '') respond(422, ['ok'=>false,'message'=>'Email and password are required.']);
        $s = $pdo->prepare('SELECT member_id, full_name, email, password_hash, membership_type FROM Members WHERE email=? LIMIT 1');
        $s->execute([$email]); $m = $s->fetch();
        if (!$m || empty($m['password_hash']) || !password_verify($password, $m['password_hash'])) respond(401, ['ok'=>false,'message'=>'Invalid email or password.']);
        // This starter returns member details only; add expiring bearer tokens before production use.
        respond(200, ['ok'=>true,'message'=>'Signed in.','member'=>['id'=>(int)$m['member_id'],'full_name'=>$m['full_name'],'email'=>$m['email'],'membership_type'=>$m['membership_type']]]);
    }
    if ($action === 'book' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $d = body(); $memberId = filter_var($d['member_id'] ?? null, FILTER_VALIDATE_INT); $classId = filter_var($d['class_id'] ?? null, FILTER_VALIDATE_INT);
        if (!$memberId || !$classId) respond(422, ['ok'=>false,'message'=>'member_id and class_id are required.']);
        $check = $pdo->prepare('SELECT class_id, capacity FROM Classes WHERE class_id=?'); $check->execute([$classId]); $class = $check->fetch();
        if (!$class) respond(404, ['ok'=>false,'message'=>'Class not found.']);
        $count = $pdo->prepare("SELECT COUNT(*) FROM Bookings WHERE class_id=? AND status='Confirmed'"); $count->execute([$classId]);
        if ((int)$count->fetchColumn() >= (int)$class['capacity']) respond(409, ['ok'=>false,'message'=>'This class is full.']);
        $member = $pdo->prepare('SELECT member_id FROM Members WHERE member_id=?'); $member->execute([$memberId]);
        if (!$member->fetch()) respond(404, ['ok'=>false,'message'=>'Member not found.']);
        $s = $pdo->prepare("INSERT INTO Bookings (member_id,class_id,booking_date,status) VALUES (?,?,CURRENT_DATE,'Confirmed')");
        $s->execute([$memberId,$classId]); respond(201,['ok'=>true,'message'=>'Booking created.','booking_id'=>(int)$pdo->lastInsertId()]);
    }
    if ($action === 'bookings' && $_SERVER['REQUEST_METHOD'] === 'GET') {
        $memberId = filter_input(INPUT_GET, 'member_id', FILTER_VALIDATE_INT);
        if (!$memberId) respond(422,['ok'=>false,'message'=>'member_id is required.']);
        $s = $pdo->prepare("SELECT b.booking_id, b.status, c.class_name AS name, DATE_FORMAT(c.schedule_date,'%Y-%m-%d') AS date, TIME_FORMAT(c.start_time,'%H:%i') AS time, t.trainer_name AS trainer FROM Bookings b JOIN Classes c ON c.class_id=b.class_id LEFT JOIN Trainers t ON t.trainer_id=c.trainer_id WHERE b.member_id=? ORDER BY c.schedule_date,c.start_time");
        $s->execute([$memberId]); respond(200,['ok'=>true,'bookings'=>$s->fetchAll()]);
    }
    respond(404, ['ok'=>false,'message'=>'Unknown API action.']);
} catch (Throwable $e) {
    error_log('FightClubSA API: '.$e->getMessage());
    respond(500, ['ok'=>false,'message'=>'Server error. Check the PHP error log.']);
}
