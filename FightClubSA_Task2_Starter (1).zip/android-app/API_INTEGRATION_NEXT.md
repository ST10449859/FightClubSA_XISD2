# Next implementation milestone: connect the app to the PHP API

Base URL for Android emulator:
`http://10.0.2.2/FightClubSA_XISD/api/index.php/`

Suggested Retrofit service routes (query parameter action):
- `GET ?action=classes`
- `POST ?action=register` JSON `{ "full_name": "...", "email": "...", "password": "..." }`
- `POST ?action=login` JSON `{ "email": "...", "password": "..." }`
- `POST ?action=book` JSON `{ "member_id": 1, "class_id": 1 }`
- `GET ?action=bookings&member_id=1`

Important: the current app does not call the API yet. Do not use the member_id booking parameter as production authorization; implement authenticated expiring tokens and derive member identity from the verified token before allowing bookings.
