package za.co.fightclubsa.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private val FightRed = Color(0xFFE3262E)
private val Ink = Color(0xFF111111)
private val Soft = Color(0xFFF4F4F2)

data class FitnessClass(val id: Int, val name: String, val trainer: String, val time: String, val level: String, val capacity: Int)

private val demoClasses = listOf(
    FitnessClass(1, "Boxing Basics", "Thabo M.", "08:00", "Beginner", 20),
    FitnessClass(2, "HIIT Boxing", "Ayanda N.", "10:00", "Intermediate", 20),
    FitnessClass(3, "Strength Lab", "Mpho K.", "12:00", "All levels", 15),
    FitnessClass(4, "Fight Conditioning", "Mpho K.", "19:30", "Advanced", 18)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FightClubApp() }
    }
}

@Composable
fun FightClubApp() {
    var screen by remember { mutableStateOf("Home") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var signedIn by remember { mutableStateOf(false) }
    var memberName by remember { mutableStateOf("FightClubSA Member") }
    var message by remember { mutableStateOf("Welcome to FightClubSA.") }
    var selectedTab by remember { mutableStateOf("Home") }
    var bookings by remember { mutableStateOf(listOf<FitnessClass>()) }
    var celsius by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }
    val snackbarHostState = remember { SnackbarHostState() }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = FightRed, onPrimary = Color.White, background = Soft, surface = Color.White)
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Home", "Classes", "Bookings", "Profile", "Settings").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab; screen = tab },
                            icon = {
                                Icon(
                                    when (tab) {
                                        "Home" -> Icons.Default.Home
                                        "Classes" -> Icons.Default.FitnessCenter
                                        "Bookings" -> Icons.Default.EventAvailable
                                        "Profile" -> Icons.Default.Person
                                        else -> Icons.Default.Settings
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) }
                        )
                    }
                }
            },
            containerColor = Soft
        ) { padding ->
            when (screen) {
                "Login" -> AuthScreen(
                    title = "Welcome back.",
                    fullName = null,
                    email = email, onEmail = { email = it },
                    password = password, onPassword = { password = it },
                    message = message,
                    primaryLabel = "LOGIN",
                    onSubmit = {
                        if (email.contains("@") && password.length >= 8) {
                            message = "Demo sign-in only. Connect the PHP API before using real accounts."
                            memberName = email.substringBefore("@").replaceFirstChar { it.uppercase() }
                            signedIn = true; screen = "Profile"; selectedTab = "Profile"
                        } else message = "Enter a valid email and a password of at least 8 characters."
                    },
                    onSwitch = { screen = "Register" },
                    switchText = "New here? Create an account"
                )
                "Register" -> AuthScreen(
                    title = "Create account.",
                    fullName = fullName, onFullName = { fullName = it },
                    email = email, onEmail = { email = it },
                    password = password, onPassword = { password = it },
                    message = message,
                    primaryLabel = "CREATE ACCOUNT",
                    onSubmit = {
                        if (fullName.isBlank() || !email.contains("@") || password.length < 8) {
                            message = "Enter your name, a valid email, and a password of at least 8 characters."
                        } else {
                            message = "Demo registration only. Connect the PHP API before creating real accounts."
                            memberName = fullName
                            screen = "Login"; selectedTab = "Profile"
                        }
                    },
                    onSwitch = { screen = "Login" },
                    switchText = "Already registered? Log in"
                )
                "Classes" -> ClassesScreen(demoClasses, onBook = { c ->
                    if (bookings.none { it.id == c.id }) bookings = bookings + c
                    message = "${c.name} added to your demo bookings."
                })
                "Bookings" -> BookingsScreen(bookings, onRemove = { c -> bookings = bookings.filterNot { it.id == c.id } })
                "Profile" -> ProfileScreen(signedIn, memberName, onLogin = { screen = "Login" }, onRegister = { screen = "Register" }, onLogout = {
                    signedIn = false; memberName = "FightClubSA Member"; screen = "Home"; selectedTab = "Home"
                })
                "Settings" -> SettingsScreen(
                    celsius = celsius, onCelsius = { celsius = it },
                    notifications = notifications, onNotifications = { notifications = it },
                    onAbout = { message = "FightClubSA mobile app • Version 1.0 • Demo build." }
                )
                else -> HomeScreen(
                    memberName = if (signedIn) memberName else "FIGHTER",
                    bookingsCount = bookings.size,
                    message = message,
                    onBrowse = { screen = "Classes"; selectedTab = "Classes" },
                    onLogin = { screen = "Login" }
                )
            }
        }
    }
}

@Composable
private fun BrandHeader(subtitle: String) {
    Column(
        Modifier.fillMaxWidth().background(Ink).padding(horizontal = 22.dp, vertical = 22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("FIGHT", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text("CLUBSA", color = FightRed, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        }
        Text(subtitle.uppercase(), color = Color.LightGray, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
    }
}

@Composable
private fun HomeScreen(memberName: String, bookingsCount: Int, message: String, onBrowse: () -> Unit, onLogin: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { BrandHeader("Box • Train • Transform") }
        item {
            Column(Modifier.padding(20.dp)) {
                Text("READY TO TRAIN?", color = FightRed, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                Text("Train harder.\nLive stronger.", fontSize = 32.sp, fontWeight = FontWeight.Black, lineHeight = 37.sp, color = Ink)
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = FightRed), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp)) {
                        Text("MEMBERSHIP STATUS", color = Color.White.copy(alpha = .8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(memberName, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                        Text("$bookingsCount demo booking(s)", color = Color.White)
                        Spacer(Modifier.height(14.dp))
                        Button(onClick = onBrowse, colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("BROWSE CLASSES") }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("UP NEXT", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Explore boxing, conditioning and strength sessions.")
                        Text(message, color = Color.Gray, fontSize = 12.sp)
                        TextButton(onClick = onLogin) { Text("Member login / register") }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("POPULAR CLASSES", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                demoClasses.take(2).forEach { ClassCard(it, booked = false, onBook = onBrowse) }
            }
        }
    }
}

@Composable
private fun ClassesScreen(classes: List<FitnessClass>, onBook: (FitnessClass) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { BrandHeader("Find your next session") }
        item { Column(Modifier.padding(horizontal = 20.dp, vertical = 16.dp)) {
            Text("All classes", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Choose a session that matches your level.", color = Color.Gray)
        } }
        items(classes) { c -> ClassCard(c, false, { onBook(c) }) }
        item { Text("Demo class data is currently shown. API integration is the next step.", Modifier.padding(20.dp), color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun ClassCard(c: FitnessClass, booked: Boolean, onBook: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 7.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(15.dp)
    ) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(FightRed.copy(alpha = .12f), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.FitnessCenter, contentDescription = null, tint = FightRed)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${c.trainer} • ${c.level}", color = Color.Gray, fontSize = 12.sp)
                }
                Text(c.time, color = FightRed, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Capacity: ${c.capacity}", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Button(onClick = onBook, colors = ButtonDefaults.buttonColors(containerColor = Ink)) {
                    Text(if (booked) "BOOKED" else "BOOK CLASS")
                }
            }
        }
    }
}

@Composable
private fun BookingsScreen(bookings: List<FitnessClass>, onRemove: (FitnessClass) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { BrandHeader("Your training schedule") }
        item { Column(Modifier.padding(20.dp)) {
            Text("My bookings", fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Bookings are stored in memory in this demo build.", color = Color.Gray, fontSize = 12.sp)
        } }
        if (bookings.isEmpty()) item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(22.dp)) {
                    Icon(Icons.Default.EventBusy, contentDescription = null, tint = FightRed, modifier = Modifier.size(35.dp))
                    Text("No bookings yet", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Open Classes and book your first session.")
                }
            }
        }
        items(bookings) { c ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.Bold)
                        Text("${c.time} • ${c.trainer}", color = Color.Gray, fontSize = 12.sp)
                    }
                    TextButton(onClick = { onRemove(c) }) { Text("Cancel", color = FightRed) }
                }
            }
        }
    }
}

@Composable
private fun ProfileScreen(signedIn: Boolean, memberName: String, onLogin: () -> Unit, onRegister: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Member profile")
        Column(Modifier.padding(22.dp)) {
            Box(Modifier.size(76.dp).background(FightRed.copy(alpha = .12f), RoundedCornerShape(40.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, contentDescription = null, tint = FightRed, modifier = Modifier.size(40.dp))
            }
            Spacer(Modifier.height(15.dp))
            Text(if (signedIn) memberName else "Welcome, fighter", fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text(if (signedIn) "Demo session active" else "Sign in to access your member profile.", color = Color.Gray)
            Spacer(Modifier.height(20.dp))
            if (signedIn) Button(onClick = onLogout) { Text("LOG OUT") }
            else {
                Button(onClick = onLogin, modifier = Modifier.fillMaxWidth()) { Text("LOGIN") }
                OutlinedButton(onClick = onRegister, modifier = Modifier.fillMaxWidth()) { Text("CREATE ACCOUNT") }
            }
            Spacer(Modifier.height(20.dp))
            Text("Security note: this starter uses a demo-only sign-in screen. It does not authenticate against MySQL yet.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Composable
private fun AuthScreen(
    title: String, fullName: String?, onFullName: (String) -> Unit = {},
    email: String, onEmail: (String) -> Unit,
    password: String, onPassword: (String) -> Unit,
    message: String, primaryLabel: String, onSubmit: () -> Unit,
    onSwitch: () -> Unit, switchText: String
) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Member access")
        Column(Modifier.fillMaxWidth().padding(22.dp)) {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Sign in to stay connected to your training.", color = Color.Gray)
            Spacer(Modifier.height(22.dp))
            if (fullName != null) OutlinedTextField(value = fullName, onValueChange = onFullName, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = email, onValueChange = onEmail, label = { Text("Email address") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = password, onValueChange = onPassword, label = { Text("Password (minimum 8 characters)") }, modifier = Modifier.fillMaxWidth(), singleLine = true, visualTransformation = PasswordVisualTransformation())
            Spacer(Modifier.height(16.dp))
            Button(onClick = onSubmit, modifier = Modifier.fillMaxWidth()) { Text(primaryLabel) }
            TextButton(onClick = onSwitch) { Text(switchText) }
            Text(message, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { /* Google SSO requires Firebase/Google OAuth project credentials. */ }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AccountCircle, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("CONTINUE WITH GOOGLE (setup required)")
            }
        }
    }
}

@Composable
private fun SettingsScreen(celsius: Boolean, onCelsius: (Boolean) -> Unit, notifications: Boolean, onNotifications: (Boolean) -> Unit, onAbout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        BrandHeader("Personal preferences")
        Column(Modifier.padding(22.dp)) {
            Text("Settings", fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("Manage your app preferences.", color = Color.Gray)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Temperature unit", fontWeight = FontWeight.Bold)
                            Text(if (celsius) "Celsius (°C)" else "Fahrenheit (°F)", color = Color.Gray, fontSize = 12.sp)
                        }
                        Switch(checked = celsius, onCheckedChange = onCelsius)
                    }
                    HorizontalDivider()
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Notifications", fontWeight = FontWeight.Bold)
                            Text("Class reminders and updates", color = Color.Gray, fontSize = 12.sp)
                        }
                        Switch(checked = notifications, onCheckedChange = onNotifications)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth()) { Text("ABOUT THIS APP") }
            Text("Settings are temporary in this starter and reset when the app restarts.", color = Color.Gray, fontSize = 12.sp)
        }
    }
}
