# FightClubSA Task 2 Starter Bundle

This bundle preserves the supplied Task 1 PHP/MySQL website and adds a native Kotlin/Jetpack Compose Android Studio starter project plus a development PHP API scaffold.

## Important status
This is a runnable starter/prototype, not a completed or production-secure submission. The Android UI currently uses demo class data and demo-only sign-in/registration. The PHP API includes class listing, registration with `password_hash`, login with `password_verify`, and basic booking endpoints, but Android Retrofit/API integration, bearer-token authentication, Google SSO/Firebase configuration, persistent settings, robust authorization, automated app tests, deployment, and the final physical-device demonstration still need to be completed and verified.

## Contents
- `FightClubSA_XISD/` - original supplied website plus `api/index.php`
- `android-app/` - Android Studio Kotlin + Jetpack Compose project
- `.github/workflows/android-ci.yml` - starter GitHub Actions Android build workflow

## Run the website
1. Copy `FightClubSA_XISD` into `C:\xampp\htdocs\`.
2. Start Apache and MySQL.
3. Import `FightClubSA_XISD/database.sql` in phpMyAdmin.
4. Open `http://localhost/FightClubSA_XISD/Index.php`.
5. API health check: `http://localhost/FightClubSA_XISD/api/index.php?action=health`
6. Class list: `http://localhost/FightClubSA_XISD/api/index.php?action=classes`

## Open Android app
1. Open Android Studio.
2. Choose **Open** and select the `android-app` folder.
3. Allow Gradle sync to finish. Use JDK 17 and install Android SDK 35 if Android Studio requests it.
4. Select an emulator and press Run.
5. The starter app should show Home, Classes, Bookings, Profile, and Settings tabs. Classes and bookings are demo/in-memory only until API integration is implemented.

## Local API address
- Android emulator: `http://10.0.2.2/FightClubSA_XISD/api/index.php`
- Physical Android phone: use your PC's LAN IPv4 address, e.g. `http://192.168.x.x/FightClubSA_XISD/api/index.php`, and ensure both devices are on the same network and Windows Firewall permits Apache.

The current app does not yet call these endpoints. Do not expose this development API publicly as-is.

## Database requirements
The original SQL seeds only a few rows in some tables. Task 2 requests at least 10 records per table; populate and verify all tables before final submission. Do not insert fake payment claims or personal data; use clearly labelled simulated test records.

## Security and coursework checklist
- Never store raw passwords. Keep using PHP `password_hash()` / `password_verify()`.
- Before public deployment, replace wildcard CORS, use HTTPS, add expiring server-issued access tokens, enforce authorization on every booking request, and configure Google SSO/Firebase with your own project credentials.
- Configure Android's Google sign-in only after creating/receiving the project's OAuth client IDs and Firebase configuration. These credentials cannot be invented for you.
- Add real unit/instrumentation tests and ensure GitHub Actions actually passes.
- Run and demonstrate the final app on a physical Android phone, as required by the brief.
- Record actual team contributions, meetings, Azure DevOps work items, lecturer feedback, and screenshots honestly.
